﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using KimchiAPI.Entities;

namespace KimchiAPI.Models
{
    public class ResponseModel
    {

        public ResponseModel(Orders orders) 
        {
            Id = orders.OrderID;
            Date = orders.OrderDate;
            Amount = orders.TotalAmount;
            Status = orders.OrderStatus;
        }

        public int Id { get; set; } 
        public DateTime? Date { get; set; } 
        public string Status { get; set; }  
        public decimal? Amount { get; set; }
    }
}