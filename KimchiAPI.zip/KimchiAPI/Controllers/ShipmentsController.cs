﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using KimchiAPI.Entities;
using KimchiAPI.Models;

namespace KimchiAPI.Controllers
{
    public class ShipmentsController : ApiController
    {
        private KimchiEntities db = new KimchiEntities();

        // GET: api/Shipments
        public IQueryable<Shipments> GetShipments()
        {
            return db.Shipments;
        }


        [Route("api/getShipment")]
        public IHttpActionResult GetProducts(int orderId)
        {
            var shipment = db.Shipments.ToList().Where(p => p.OrderID == orderId).ToList();
            return Ok(shipment);
        }

        // GET: api/Shipments/5
        [ResponseType(typeof(Shipments))]
        public IHttpActionResult GetShipments(int id)
        {
            Shipments shipments = db.Shipments.Find(id);
            if (shipments == null)
            {
                return NotFound();
            }

            return Ok(shipments);
        }

        // PUT: api/Shipments/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutShipments(int id, Shipments shipments)
        {

            if (string.IsNullOrWhiteSpace(shipments.ShipmentAddress) || shipments.ShipmentAddress.Length > 255)
            {
                ModelState.AddModelError("Adress", "Adress is required up to 255 symbols");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != shipments.ShipmentID)
            {
                return BadRequest();
            }

            db.Entry(shipments).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ShipmentsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Shipments
        [ResponseType(typeof(Shipments))]
        public IHttpActionResult PostShipments(Shipments shipments)
        {
            
            shipments.ShipmentDate = DateTime.Now;

            if (string.IsNullOrWhiteSpace(shipments.ShipmentAddress) || shipments.ShipmentAddress.Length > 255)
            {
                ModelState.AddModelError("Adress", "Adress is required up to 255 symbols");
            }
            if (string.IsNullOrWhiteSpace(shipments.ShipmentStatus) || shipments.ShipmentStatus.Length > 20)
            {
                ModelState.AddModelError("Status", "Status is required up to 20 symbols");
            }
            if (!(db.Orders.ToList().FirstOrDefault(p => p.OrderID == shipments.OrderID) is Orders))
            {
                ModelState.AddModelError("OrderID", "No orders in database");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Shipments.Add(shipments);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = shipments.ShipmentID }, shipments);
        }

        // DELETE: api/Shipments/5
        [ResponseType(typeof(Shipments))]
        public IHttpActionResult DeleteShipments(int id)
        {
            Shipments shipments = db.Shipments.Find(id);
            if (shipments == null)
            {
                return NotFound();
            }

            db.Shipments.Remove(shipments);
            db.SaveChanges();

            return Ok(shipments);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ShipmentsExists(int id)
        {
            return db.Shipments.Count(e => e.ShipmentID == id) > 0;
        }
    }
}